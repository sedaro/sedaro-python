from .python_client.openapi_client import Configuration

config = Configuration(
    host='http://localhost:8000/',
)
