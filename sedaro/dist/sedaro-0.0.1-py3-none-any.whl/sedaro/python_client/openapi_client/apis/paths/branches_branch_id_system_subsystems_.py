from openapi_client.paths.branches_branch_id_system_subsystems_.post import ApiForpost


class BranchesBranchIdSystemSubsystems(
    ApiForpost,
):
    pass
