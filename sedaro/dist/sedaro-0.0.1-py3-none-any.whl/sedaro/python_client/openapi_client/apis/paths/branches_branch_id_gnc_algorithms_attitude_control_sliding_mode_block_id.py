from openapi_client.paths.branches_branch_id_gnc_algorithms_attitude_control_sliding_mode_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_algorithms_attitude_control_sliding_mode_block_id.patch import ApiForpatch


class BranchesBranchIdGncAlgorithmsAttitudeControlSlidingModeBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
