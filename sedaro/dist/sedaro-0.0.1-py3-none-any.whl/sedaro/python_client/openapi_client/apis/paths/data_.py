from openapi_client.paths.data_.get import ApiForget


class Data(
    ApiForget,
):
    pass
