from openapi_client.paths.branches_branch_id_system_geometry_body_frame_vectors_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_system_geometry_body_frame_vectors_block_id.patch import ApiForpatch


class BranchesBranchIdSystemGeometryBodyFrameVectorsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
