from openapi_client.paths.branches_branch_idshare_auth_.post import ApiForpost


class BranchesBranchIdshareAuth(
    ApiForpost,
):
    pass
