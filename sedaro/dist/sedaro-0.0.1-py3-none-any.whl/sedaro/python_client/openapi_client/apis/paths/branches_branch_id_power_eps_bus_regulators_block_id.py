from openapi_client.paths.branches_branch_id_power_eps_bus_regulators_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_power_eps_bus_regulators_block_id.patch import ApiForpatch


class BranchesBranchIdPowerEpsBusRegulatorsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
