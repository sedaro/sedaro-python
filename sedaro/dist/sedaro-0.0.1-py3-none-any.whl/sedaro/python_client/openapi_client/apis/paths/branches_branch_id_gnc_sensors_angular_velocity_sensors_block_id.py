from openapi_client.paths.branches_branch_id_gnc_sensors_angular_velocity_sensors_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_sensors_angular_velocity_sensors_block_id.patch import ApiForpatch


class BranchesBranchIdGncSensorsAngularVelocitySensorsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
