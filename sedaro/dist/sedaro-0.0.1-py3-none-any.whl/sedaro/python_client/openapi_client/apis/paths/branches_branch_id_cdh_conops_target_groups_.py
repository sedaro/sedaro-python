from openapi_client.paths.branches_branch_id_cdh_conops_target_groups_.post import ApiForpost


class BranchesBranchIdCdhConopsTargetGroups(
    ApiForpost,
):
    pass
