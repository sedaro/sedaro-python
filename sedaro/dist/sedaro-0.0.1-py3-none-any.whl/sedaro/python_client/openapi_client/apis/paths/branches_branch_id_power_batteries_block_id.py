from openapi_client.paths.branches_branch_id_power_batteries_block_id.patch import ApiForpatch


class BranchesBranchIdPowerBatteriesBlockId(
    ApiForpatch,
):
    pass
