from openapi_client.paths.branches_branch_id_clock_configs_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_clock_configs_block_id.patch import ApiForpatch


class BranchesBranchIdClockConfigsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
