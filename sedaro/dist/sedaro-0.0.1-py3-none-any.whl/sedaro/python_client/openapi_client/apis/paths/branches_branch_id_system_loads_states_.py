from openapi_client.paths.branches_branch_id_system_loads_states_.post import ApiForpost


class BranchesBranchIdSystemLoadsStates(
    ApiForpost,
):
    pass
