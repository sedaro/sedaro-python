from openapi_client.paths.branches_branch_id_gnc_algorithms_attitude_determination_mekf_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_algorithms_attitude_determination_mekf_block_id.patch import ApiForpatch


class BranchesBranchIdGncAlgorithmsAttitudeDeterminationMekfBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
