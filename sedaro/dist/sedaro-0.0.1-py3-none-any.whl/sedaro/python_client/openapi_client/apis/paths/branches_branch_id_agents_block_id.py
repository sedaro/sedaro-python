from openapi_client.paths.branches_branch_id_agents_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_agents_block_id.patch import ApiForpatch


class BranchesBranchIdAgentsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
