from openapi_client.paths.branches_branch_id_system_geometry_surfaces_materials_.post import ApiForpost


class BranchesBranchIdSystemGeometrySurfacesMaterials(
    ApiForpost,
):
    pass
