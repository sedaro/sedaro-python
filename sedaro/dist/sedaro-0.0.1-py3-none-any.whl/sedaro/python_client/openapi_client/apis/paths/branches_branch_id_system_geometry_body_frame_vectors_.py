from openapi_client.paths.branches_branch_id_system_geometry_body_frame_vectors_.post import ApiForpost


class BranchesBranchIdSystemGeometryBodyFrameVectors(
    ApiForpost,
):
    pass
