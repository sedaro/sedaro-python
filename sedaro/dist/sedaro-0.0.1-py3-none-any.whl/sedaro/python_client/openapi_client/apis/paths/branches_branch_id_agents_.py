from openapi_client.paths.branches_branch_id_agents_.post import ApiForpost


class BranchesBranchIdAgents(
    ApiForpost,
):
    pass
