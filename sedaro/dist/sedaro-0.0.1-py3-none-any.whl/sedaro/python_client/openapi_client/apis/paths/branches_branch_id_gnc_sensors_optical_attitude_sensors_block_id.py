from openapi_client.paths.branches_branch_id_gnc_sensors_optical_attitude_sensors_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_sensors_optical_attitude_sensors_block_id.patch import ApiForpatch


class BranchesBranchIdGncSensorsOpticalAttitudeSensorsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
