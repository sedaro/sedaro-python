from openapi_client.paths.branches_branch_id_gnc_sensors_angular_velocity_sensors_.post import ApiForpost


class BranchesBranchIdGncSensorsAngularVelocitySensors(
    ApiForpost,
):
    pass
