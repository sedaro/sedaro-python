from openapi_client.paths.branches_branch_id_cdh_conops_operational_modes_.post import ApiForpost


class BranchesBranchIdCdhConopsOperationalModes(
    ApiForpost,
):
    pass
