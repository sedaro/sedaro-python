from openapi_client.paths.branches_branch_id_system_subsystems_components_.post import ApiForpost


class BranchesBranchIdSystemSubsystemsComponents(
    ApiForpost,
):
    pass
