from openapi_client.paths.branches_branch_id_gnc_algorithms_orbit_determination_gps_.post import ApiForpost


class BranchesBranchIdGncAlgorithmsOrbitDeterminationGps(
    ApiForpost,
):
    pass
