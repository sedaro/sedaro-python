from openapi_client.paths.branches_branch_id_gnc_pointing_modes_lock_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_pointing_modes_lock_block_id.patch import ApiForpatch


class BranchesBranchIdGncPointingModesLockBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
