from openapi_client.paths.branches_branch_id_gnc_sensors_position_sensors_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_sensors_position_sensors_block_id.patch import ApiForpatch


class BranchesBranchIdGncSensorsPositionSensorsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
