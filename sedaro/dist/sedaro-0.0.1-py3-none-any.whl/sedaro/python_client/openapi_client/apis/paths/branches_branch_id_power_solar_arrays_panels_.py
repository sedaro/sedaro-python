from openapi_client.paths.branches_branch_id_power_solar_arrays_panels_.post import ApiForpost


class BranchesBranchIdPowerSolarArraysPanels(
    ApiForpost,
):
    pass
