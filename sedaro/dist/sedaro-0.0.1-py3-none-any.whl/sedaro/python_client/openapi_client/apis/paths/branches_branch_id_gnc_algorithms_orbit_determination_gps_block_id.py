from openapi_client.paths.branches_branch_id_gnc_algorithms_orbit_determination_gps_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_algorithms_orbit_determination_gps_block_id.patch import ApiForpatch


class BranchesBranchIdGncAlgorithmsOrbitDeterminationGpsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
