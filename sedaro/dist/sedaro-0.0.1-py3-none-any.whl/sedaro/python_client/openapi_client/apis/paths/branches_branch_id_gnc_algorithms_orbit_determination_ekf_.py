from openapi_client.paths.branches_branch_id_gnc_algorithms_orbit_determination_ekf_.post import ApiForpost


class BranchesBranchIdGncAlgorithmsOrbitDeterminationEkf(
    ApiForpost,
):
    pass
