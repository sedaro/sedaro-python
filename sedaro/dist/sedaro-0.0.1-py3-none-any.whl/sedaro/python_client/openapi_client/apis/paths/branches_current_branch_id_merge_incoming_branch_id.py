from openapi_client.paths.branches_current_branch_id_merge_incoming_branch_id.post import ApiForpost


class BranchesCurrentBranchIdMergeIncomingBranchId(
    ApiForpost,
):
    pass
