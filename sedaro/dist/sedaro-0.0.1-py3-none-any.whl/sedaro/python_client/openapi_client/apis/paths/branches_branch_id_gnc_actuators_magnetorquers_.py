from openapi_client.paths.branches_branch_id_gnc_actuators_magnetorquers_.post import ApiForpost


class BranchesBranchIdGncActuatorsMagnetorquers(
    ApiForpost,
):
    pass
