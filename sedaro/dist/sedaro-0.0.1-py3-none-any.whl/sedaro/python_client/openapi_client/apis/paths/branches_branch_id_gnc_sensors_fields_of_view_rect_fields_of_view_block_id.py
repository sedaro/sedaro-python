from openapi_client.paths.branches_branch_id_gnc_sensors_fields_of_view_rect_fields_of_view_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_sensors_fields_of_view_rect_fields_of_view_block_id.patch import ApiForpatch


class BranchesBranchIdGncSensorsFieldsOfViewRectFieldsOfViewBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
