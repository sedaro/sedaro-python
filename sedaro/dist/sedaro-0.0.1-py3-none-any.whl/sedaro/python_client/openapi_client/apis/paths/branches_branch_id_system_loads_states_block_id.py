from openapi_client.paths.branches_branch_id_system_loads_states_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_system_loads_states_block_id.patch import ApiForpatch


class BranchesBranchIdSystemLoadsStatesBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
