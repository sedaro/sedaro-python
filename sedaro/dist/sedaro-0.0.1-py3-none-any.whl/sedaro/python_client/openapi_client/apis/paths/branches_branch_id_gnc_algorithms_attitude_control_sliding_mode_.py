from openapi_client.paths.branches_branch_id_gnc_algorithms_attitude_control_sliding_mode_.post import ApiForpost


class BranchesBranchIdGncAlgorithmsAttitudeControlSlidingMode(
    ApiForpost,
):
    pass
