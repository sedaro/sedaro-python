from openapi_client.paths.branches_branch_id_gnc_sensors_fields_of_view_constraints_.post import ApiForpost


class BranchesBranchIdGncSensorsFieldsOfViewConstraints(
    ApiForpost,
):
    pass
