from openapi_client.paths.branches_branch_id_gnc_actuators_reaction_wheels_.post import ApiForpost


class BranchesBranchIdGncActuatorsReactionWheels(
    ApiForpost,
):
    pass
