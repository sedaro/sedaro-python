from openapi_client.paths.branches_branch_id_power_eps_bus_regulators_.post import ApiForpost


class BranchesBranchIdPowerEpsBusRegulators(
    ApiForpost,
):
    pass
