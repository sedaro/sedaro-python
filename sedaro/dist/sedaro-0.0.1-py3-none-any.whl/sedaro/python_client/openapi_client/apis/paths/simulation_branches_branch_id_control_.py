from openapi_client.paths.simulation_branches_branch_id_control_.post import ApiForpost


class SimulationBranchesBranchIdControl(
    ApiForpost,
):
    pass
