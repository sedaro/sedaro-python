from openapi_client.paths.branches_branch_id_power_solar_arrays_.post import ApiForpost


class BranchesBranchIdPowerSolarArrays(
    ApiForpost,
):
    pass
