from openapi_client.paths.branches_branch_id_system_geometry_surfaces_materials_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_system_geometry_surfaces_materials_block_id.patch import ApiForpatch


class BranchesBranchIdSystemGeometrySurfacesMaterialsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
