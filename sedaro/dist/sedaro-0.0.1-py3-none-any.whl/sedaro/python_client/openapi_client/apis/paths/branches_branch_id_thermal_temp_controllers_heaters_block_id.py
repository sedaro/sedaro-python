from openapi_client.paths.branches_branch_id_thermal_temp_controllers_heaters_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_thermal_temp_controllers_heaters_block_id.patch import ApiForpatch


class BranchesBranchIdThermalTempControllersHeatersBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
