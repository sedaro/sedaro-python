from openapi_client.paths.branches_branch_id_thermal_thermal_interface_materials_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_thermal_thermal_interface_materials_block_id.patch import ApiForpatch


class BranchesBranchIdThermalThermalInterfaceMaterialsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
