from openapi_client.paths.branches_branch_id_gnc_sensors_fields_of_view_constraints_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_sensors_fields_of_view_constraints_block_id.patch import ApiForpatch


class BranchesBranchIdGncSensorsFieldsOfViewConstraintsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
