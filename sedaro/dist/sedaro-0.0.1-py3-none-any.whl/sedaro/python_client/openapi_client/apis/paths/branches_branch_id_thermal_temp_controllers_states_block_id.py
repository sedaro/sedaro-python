from openapi_client.paths.branches_branch_id_thermal_temp_controllers_states_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_thermal_temp_controllers_states_block_id.patch import ApiForpatch


class BranchesBranchIdThermalTempControllersStatesBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
