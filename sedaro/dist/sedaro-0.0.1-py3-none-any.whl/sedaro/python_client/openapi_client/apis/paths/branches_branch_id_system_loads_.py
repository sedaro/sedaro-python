from openapi_client.paths.branches_branch_id_system_loads_.post import ApiForpost


class BranchesBranchIdSystemLoads(
    ApiForpost,
):
    pass
