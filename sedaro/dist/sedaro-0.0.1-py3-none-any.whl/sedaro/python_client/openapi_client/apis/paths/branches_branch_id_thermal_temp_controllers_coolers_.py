from openapi_client.paths.branches_branch_id_thermal_temp_controllers_coolers_.post import ApiForpost


class BranchesBranchIdThermalTempControllersCoolers(
    ApiForpost,
):
    pass
