from openapi_client.paths.branches_branch_id.get import ApiForget
from openapi_client.paths.branches_branch_id.post import ApiForpost
from openapi_client.paths.branches_branch_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id.patch import ApiForpatch


class BranchesBranchId(
    ApiForget,
    ApiForpost,
    ApiFordelete,
    ApiForpatch,
):
    pass
