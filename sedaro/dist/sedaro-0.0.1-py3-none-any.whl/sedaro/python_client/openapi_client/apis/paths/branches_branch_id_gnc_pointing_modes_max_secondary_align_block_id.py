from openapi_client.paths.branches_branch_id_gnc_pointing_modes_max_secondary_align_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_pointing_modes_max_secondary_align_block_id.patch import ApiForpatch


class BranchesBranchIdGncPointingModesMaxSecondaryAlignBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
