from openapi_client.paths.branches_branch_idsaved_.get import ApiForget


class BranchesBranchIdsaved(
    ApiForget,
):
    pass
