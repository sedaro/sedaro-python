from openapi_client.paths.branches_branch_id_thermal_thermal_interface_materials_.post import ApiForpost


class BranchesBranchIdThermalThermalInterfaceMaterials(
    ApiForpost,
):
    pass
