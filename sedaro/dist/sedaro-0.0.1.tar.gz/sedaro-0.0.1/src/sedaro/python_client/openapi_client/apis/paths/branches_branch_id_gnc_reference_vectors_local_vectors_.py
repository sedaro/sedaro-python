from openapi_client.paths.branches_branch_id_gnc_reference_vectors_local_vectors_.post import ApiForpost


class BranchesBranchIdGncReferenceVectorsLocalVectors(
    ApiForpost,
):
    pass
