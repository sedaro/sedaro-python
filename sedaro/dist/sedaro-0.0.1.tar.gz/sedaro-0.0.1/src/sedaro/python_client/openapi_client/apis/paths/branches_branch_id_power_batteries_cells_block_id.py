from openapi_client.paths.branches_branch_id_power_batteries_cells_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_power_batteries_cells_block_id.patch import ApiForpatch


class BranchesBranchIdPowerBatteriesCellsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
