from openapi_client.paths.branches_branch_idcommits_.post import ApiForpost


class BranchesBranchIdcommits(
    ApiForpost,
):
    pass
