from openapi_client.paths.branches_branch_id_gnc_pointing_modes_max_secondary_align_.post import ApiForpost


class BranchesBranchIdGncPointingModesMaxSecondaryAlign(
    ApiForpost,
):
    pass
