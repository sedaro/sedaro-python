from openapi_client.paths.branches_branch_id_power_batteries_packs_.post import ApiForpost


class BranchesBranchIdPowerBatteriesPacks(
    ApiForpost,
):
    pass
