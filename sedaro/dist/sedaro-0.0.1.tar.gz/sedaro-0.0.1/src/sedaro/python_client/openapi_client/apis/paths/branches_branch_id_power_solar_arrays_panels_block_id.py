from openapi_client.paths.branches_branch_id_power_solar_arrays_panels_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_power_solar_arrays_panels_block_id.patch import ApiForpatch


class BranchesBranchIdPowerSolarArraysPanelsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
