from openapi_client.paths.branches_branch_id_thermal_thermal_interfaces_.post import ApiForpost


class BranchesBranchIdThermalThermalInterfaces(
    ApiForpost,
):
    pass
