from openapi_client.paths.branches_branch_id_clock_configs_.post import ApiForpost


class BranchesBranchIdClockConfigs(
    ApiForpost,
):
    pass
