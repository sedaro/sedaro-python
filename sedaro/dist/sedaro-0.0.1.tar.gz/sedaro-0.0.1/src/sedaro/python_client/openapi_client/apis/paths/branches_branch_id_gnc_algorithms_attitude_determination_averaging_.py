from openapi_client.paths.branches_branch_id_gnc_algorithms_attitude_determination_averaging_.post import ApiForpost


class BranchesBranchIdGncAlgorithmsAttitudeDeterminationAveraging(
    ApiForpost,
):
    pass
