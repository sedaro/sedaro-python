from openapi_client.paths.branches_branch_id_gnc_sensors_direction_sensors_.post import ApiForpost


class BranchesBranchIdGncSensorsDirectionSensors(
    ApiForpost,
):
    pass
