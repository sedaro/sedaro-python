from openapi_client.paths.branches_branch_id_gnc_reference_vectors_celestial_vectors_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_reference_vectors_celestial_vectors_block_id.patch import ApiForpatch


class BranchesBranchIdGncReferenceVectorsCelestialVectorsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
