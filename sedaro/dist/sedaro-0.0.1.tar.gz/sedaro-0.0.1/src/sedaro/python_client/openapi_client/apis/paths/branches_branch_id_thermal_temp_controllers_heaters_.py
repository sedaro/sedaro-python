from openapi_client.paths.branches_branch_id_thermal_temp_controllers_heaters_.post import ApiForpost


class BranchesBranchIdThermalTempControllersHeaters(
    ApiForpost,
):
    pass
