from openapi_client.paths.branches_branch_id_gnc_sensors_optical_attitude_sensors_.post import ApiForpost


class BranchesBranchIdGncSensorsOpticalAttitudeSensors(
    ApiForpost,
):
    pass
