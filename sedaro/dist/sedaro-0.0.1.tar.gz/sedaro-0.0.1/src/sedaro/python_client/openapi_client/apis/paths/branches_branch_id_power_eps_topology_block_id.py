from openapi_client.paths.branches_branch_id_power_eps_topology_block_id.patch import ApiForpatch


class BranchesBranchIdPowerEpsTopologyBlockId(
    ApiForpatch,
):
    pass
