from openapi_client.paths.branches_branch_id_cdh_conops_space_targets_.post import ApiForpost


class BranchesBranchIdCdhConopsSpaceTargets(
    ApiForpost,
):
    pass
