from openapi_client.paths.branches_branch_idcommitted_.get import ApiForget


class BranchesBranchIdcommitted(
    ApiForget,
):
    pass
