from openapi_client.paths.branches_branch_id_gnc_orbits_block_id.patch import ApiForpatch


class BranchesBranchIdGncOrbitsBlockId(
    ApiForpatch,
):
    pass
