from openapi_client.paths.branches_branch_id_power_batteries_cells_.post import ApiForpost


class BranchesBranchIdPowerBatteriesCells(
    ApiForpost,
):
    pass
