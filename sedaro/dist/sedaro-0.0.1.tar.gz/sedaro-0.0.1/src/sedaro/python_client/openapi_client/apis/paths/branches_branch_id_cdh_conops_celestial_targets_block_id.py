from openapi_client.paths.branches_branch_id_cdh_conops_celestial_targets_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_cdh_conops_celestial_targets_block_id.patch import ApiForpatch


class BranchesBranchIdCdhConopsCelestialTargetsBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
