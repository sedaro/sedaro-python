from openapi_client.paths.branches_branch_id_gnc_sensors_fields_of_view_rect_fields_of_view_.post import ApiForpost


class BranchesBranchIdGncSensorsFieldsOfViewRectFieldsOfView(
    ApiForpost,
):
    pass
