from openapi_client.paths.branches_branch_id_gnc_algorithms_attitude_determination_averaging_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_algorithms_attitude_determination_averaging_block_id.patch import ApiForpatch


class BranchesBranchIdGncAlgorithmsAttitudeDeterminationAveragingBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
