from openapi_client.paths.branches_branch_id_thermal_temp_controllers_states_.post import ApiForpost


class BranchesBranchIdThermalTempControllersStates(
    ApiForpost,
):
    pass
