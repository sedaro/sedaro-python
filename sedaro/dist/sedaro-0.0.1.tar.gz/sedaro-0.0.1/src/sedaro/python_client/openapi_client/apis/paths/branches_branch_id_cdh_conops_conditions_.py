from openapi_client.paths.branches_branch_id_cdh_conops_conditions_.post import ApiForpost


class BranchesBranchIdCdhConopsConditions(
    ApiForpost,
):
    pass
