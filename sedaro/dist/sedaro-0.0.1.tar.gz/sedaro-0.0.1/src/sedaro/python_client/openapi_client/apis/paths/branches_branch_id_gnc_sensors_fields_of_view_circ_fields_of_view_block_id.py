from openapi_client.paths.branches_branch_id_gnc_sensors_fields_of_view_circ_fields_of_view_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_sensors_fields_of_view_circ_fields_of_view_block_id.patch import ApiForpatch


class BranchesBranchIdGncSensorsFieldsOfViewCircFieldsOfViewBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
