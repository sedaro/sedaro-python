from openapi_client.paths.simulation_branches_branch_id_control_job_id.get import ApiForget
from openapi_client.paths.simulation_branches_branch_id_control_job_id.delete import ApiFordelete
from openapi_client.paths.simulation_branches_branch_id_control_job_id.patch import ApiForpatch


class SimulationBranchesBranchIdControlJobId(
    ApiForget,
    ApiFordelete,
    ApiForpatch,
):
    pass
