from openapi_client.paths.branches_branch_id_gnc_algorithms_attitude_determination_mekf_.post import ApiForpost


class BranchesBranchIdGncAlgorithmsAttitudeDeterminationMekf(
    ApiForpost,
):
    pass
