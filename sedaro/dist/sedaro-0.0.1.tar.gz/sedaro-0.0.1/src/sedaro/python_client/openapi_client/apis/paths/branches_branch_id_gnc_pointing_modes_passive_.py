from openapi_client.paths.branches_branch_id_gnc_pointing_modes_passive_.post import ApiForpost


class BranchesBranchIdGncPointingModesPassive(
    ApiForpost,
):
    pass
