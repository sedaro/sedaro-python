from openapi_client.paths.branches_branch_id_system_loads_temp_control_loads_.post import ApiForpost


class BranchesBranchIdSystemLoadsTempControlLoads(
    ApiForpost,
):
    pass
