from openapi_client.paths.branches_branch_id_gnc_sensors_position_sensors_.post import ApiForpost


class BranchesBranchIdGncSensorsPositionSensors(
    ApiForpost,
):
    pass
