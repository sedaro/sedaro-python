# do not import all endpoints into this module because that uses a lot of memory and stack frames
# if you need the ability to import all endpoints from this module, import them with
# from openapi_client.paths.branches_branch_id_cdh_conops_operational_modes_ import Api

from openapi_client.paths import PathValues

path = PathValues.BRANCHES_BRANCH_ID_CDH_CONOPS_OPERATIONALMODES_