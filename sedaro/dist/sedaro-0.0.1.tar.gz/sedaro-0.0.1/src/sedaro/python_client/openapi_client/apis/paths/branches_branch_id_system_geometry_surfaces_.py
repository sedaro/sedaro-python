from openapi_client.paths.branches_branch_id_system_geometry_surfaces_.post import ApiForpost


class BranchesBranchIdSystemGeometrySurfaces(
    ApiForpost,
):
    pass
