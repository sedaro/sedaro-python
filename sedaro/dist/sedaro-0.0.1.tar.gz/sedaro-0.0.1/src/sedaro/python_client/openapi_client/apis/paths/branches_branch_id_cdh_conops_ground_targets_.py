from openapi_client.paths.branches_branch_id_cdh_conops_ground_targets_.post import ApiForpost


class BranchesBranchIdCdhConopsGroundTargets(
    ApiForpost,
):
    pass
