from openapi_client.paths.branches_branch_id_template_refs_.post import ApiForpost


class BranchesBranchIdTemplateRefs(
    ApiForpost,
):
    pass
