from openapi_client.paths.branches_branch_id_system_loads_actuator_loads_.post import ApiForpost


class BranchesBranchIdSystemLoadsActuatorLoads(
    ApiForpost,
):
    pass
