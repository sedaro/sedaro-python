from openapi_client.paths.branches_branch_id_gnc_reference_vectors_target_vectors_.post import ApiForpost


class BranchesBranchIdGncReferenceVectorsTargetVectors(
    ApiForpost,
):
    pass
