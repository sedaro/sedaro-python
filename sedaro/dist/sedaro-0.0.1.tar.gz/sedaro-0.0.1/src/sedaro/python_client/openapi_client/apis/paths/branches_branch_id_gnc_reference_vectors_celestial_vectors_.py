from openapi_client.paths.branches_branch_id_gnc_reference_vectors_celestial_vectors_.post import ApiForpost


class BranchesBranchIdGncReferenceVectorsCelestialVectors(
    ApiForpost,
):
    pass
