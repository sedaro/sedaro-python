from openapi_client.paths.branches_branch_id_cdh_conops_celestial_targets_.post import ApiForpost


class BranchesBranchIdCdhConopsCelestialTargets(
    ApiForpost,
):
    pass
