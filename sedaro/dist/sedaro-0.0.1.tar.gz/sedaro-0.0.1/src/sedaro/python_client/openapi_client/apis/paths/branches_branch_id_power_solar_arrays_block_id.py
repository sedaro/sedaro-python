from openapi_client.paths.branches_branch_id_power_solar_arrays_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_power_solar_arrays_block_id.patch import ApiForpatch


class BranchesBranchIdPowerSolarArraysBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
