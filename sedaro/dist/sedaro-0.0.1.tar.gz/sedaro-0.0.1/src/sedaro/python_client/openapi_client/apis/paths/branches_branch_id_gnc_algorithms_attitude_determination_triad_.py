from openapi_client.paths.branches_branch_id_gnc_algorithms_attitude_determination_triad_.post import ApiForpost


class BranchesBranchIdGncAlgorithmsAttitudeDeterminationTriad(
    ApiForpost,
):
    pass
