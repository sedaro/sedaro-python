from openapi_client.paths.branches_branch_id_gnc_algorithms_attitude_determination_triad_block_id.delete import ApiFordelete
from openapi_client.paths.branches_branch_id_gnc_algorithms_attitude_determination_triad_block_id.patch import ApiForpatch


class BranchesBranchIdGncAlgorithmsAttitudeDeterminationTriadBlockId(
    ApiFordelete,
    ApiForpatch,
):
    pass
