# Sedaro Python Client

- In parent directory to this directory, set up virtual environment and install dependencies:
  - run `python3 sedaro_python_client/setup_virtual_env.py` or `python sedaro_python_client/setup_virtual_env.py`

_Note: requires python to be installed on the computer or a virtual environment to be created in the directory._
